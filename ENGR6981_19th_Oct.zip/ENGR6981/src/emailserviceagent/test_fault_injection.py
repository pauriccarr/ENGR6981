"""
EmailServiceAgent Fault Injection Test Runner
===============================================
Tests all FAULT_MODE values by calling graph nodes directly,
mocking generate_email_content and EmailServiceClient so no
LLM or gRPC server is needed.

Usage:
    python test_fault_injection.py
    python test_fault_injection.py FM_2_2 BL_SEND_SKIPPED
"""

import json
import os
import sys
import importlib
from datetime import datetime, timezone
from unittest.mock import MagicMock, patch

# ── Stub langgraph so graph.py can be imported without the package installed ──
_mock_langgraph_graph = MagicMock()
_mock_langgraph_graph.END = "__end__"
_mock_langgraph_graph.StateGraph = MagicMock()
sys.modules.setdefault("langgraph", MagicMock())
sys.modules["langgraph.graph"] = _mock_langgraph_graph
# Stub gRPC and proto stubs (grpc_client.py imports these at module level)
sys.modules.setdefault("grpc", MagicMock())
sys.modules.setdefault("demo_pb2", MagicMock())
sys.modules.setdefault("demo_pb2_grpc", MagicMock())

MOCK_GENERATE_RESULT = {
    "email_type": "order_confirmation",
    "subject": "Your order has been confirmed",
    "body": "Hello Customer, your order ORDER-123 is confirmed. Total: 29.99 USD.",
    "llm_used": False,
    "total_input_tokens": 0,
    "total_output_tokens": 0,
    "total_llm_calls": 0,
    "total_tokens": 0,
}

MOCK_SEND_RESULT = {"status": "sent"}

TEST_PAYLOAD = {
    "email":            "customer@example.com",
    "order_id":         "ORDER-123",
    "user_name":        "Customer",
    "currency_code":    "USD",
    "total":            29.99,
    "items":            [{"name": "Hat", "quantity": 1, "price": "29.99"}],
    "shipping_address": {"street_address": "123 Main St", "city": "Springfield",
                         "state": "IL", "country": "US", "zip_code": 62701},
}

INITIAL_STATE = {
    "request":            TEST_PAYLOAD,
    "email_type":         "",
    "subject":            "",
    "body":               "",
    "llm_used":           False,
    "microservice_status": "",
}

ALL_MODES = [
    "NONE", "FM_3_1", "FM_2_2", "FM_2_5", "FM_1_2",
    "BL_SEND_SKIPPED", "BL_DOUBLE_SEND", "BL_CORRUPTED_BODY", "BL_WRONG_CUSTOMER",
]

EXPECTED_STEPS = ["TASK_START", "EMAIL_GENERATED", "EMAIL_SENT", "FINAL_ANSWER"]


def run_one(fault_mode: str) -> dict:
    os.environ["FAULT_MODE"] = fault_mode

    # Fresh fi_mod per run so FAULT_MODE and _global_lkw are reset.
    # Do NOT evict app.graph — re-importing it has partial-init issues on SPEED.
    # The cached graph_mod is reused; we rebind graph_mod.fi so node functions
    # (which look up 'fi' in graph_mod.__dict__ at call time) see the new fi_mod.
    sys.modules.pop("app.fault_injection", None)
    import app.fault_injection as fi_mod
    import app.graph as graph_mod

    # Monkeypatch record_checkpoint to capture LKW locally — bypasses _global_lkw
    # state issues on SPEED.  Also replace with patch() with direct attribute
    # assignment: patch() calls _importer("app.graph") which re-runs the module
    # import machinery and resets graph_mod.fi on Python 3.9/SPEED.
    _lkw = []
    _orig_record = fi_mod.record_checkpoint
    def _capture(step, data):
        _lkw.append({"step": step, "fault_mode": fault_mode, "data": data})
        try:
            _orig_record(step, data)
        except Exception:
            pass
    fi_mod.record_checkpoint = _capture
    graph_mod.fi = fi_mod   # rebind so nodes call our _capture via fi.record_checkpoint

    state = dict(INITIAL_STATE)
    state["request"] = dict(TEST_PAYLOAD)

    mock_client = MagicMock()
    mock_client.send_confirmation_email.return_value = dict(MOCK_SEND_RESULT)

    # Direct attribute patching — avoids patch() _importer interference
    _orig_generate = graph_mod.generate_email_content
    _orig_client   = graph_mod.EmailServiceClient
    graph_mod.generate_email_content = lambda req: dict(MOCK_GENERATE_RESULT)
    graph_mod.EmailServiceClient     = lambda *a, **kw: mock_client

    start = datetime.now(timezone.utc)
    try:
        state = graph_mod.run_agent_node(state)
        state = graph_mod.send_via_microservice_node(state)
    finally:
        graph_mod.generate_email_content = _orig_generate
        graph_mod.EmailServiceClient     = _orig_client
    elapsed_ms = (datetime.now(timezone.utc) - start).total_seconds() * 1000

    lkw = _lkw
    steps_reached = [cp["step"] for cp in lkw]
    steps_lost = [s for s in EXPECTED_STEPS if s not in steps_reached]

    # Inline rip_summary (fi_mod.rip_summary reads _global_lkw which may differ)
    _inf_flags = {"hallucinated", "recipient_swapped", "type_wrong", "send_skipped",
                  "double_send", "corrupted", "wrong_customer", "premature_termination"}
    infection_point = None
    for cp in lkw:
        if any(cp["data"].get(k) for k in _inf_flags):
            if infection_point is None:
                infection_point = cp["step"]

    return {
        "fault_mode": fault_mode,
        "elapsed_ms": round(elapsed_ms, 1),
        "steps_reached": steps_reached,
        "steps_lost": steps_lost,
        "infection_point": infection_point,
        "propagation_depth": len(steps_lost),
        "state": {
            "email_type":          state.get("email_type"),
            "subject":             state.get("subject", "")[:60],
            "body_len":            len(state.get("body", "")),
            "microservice_status": state.get("microservice_status"),
        },
        "lkw": lkw,
    }


def print_report(results):
    print("\n" + "=" * 72)
    print("  EMAILSERVICEAGENT FAULT INJECTION — TEST REPORT")
    print("=" * 72)
    for r in results:
        label = "PASS" if r["fault_mode"] == "NONE" else "FAULT"
        print(f"\n  [{label}] {r['fault_mode']}")
        print(f"  Steps    : {' → '.join(r['steps_reached']) if r['steps_reached'] else 'NONE'}")
        if r["steps_lost"]:
            print(f"  Lost     : {', '.join(r['steps_lost'])}")
        print(f"  Infects  : {r['infection_point'] or 'none'}")
        print(f"  Prop.    : {r['propagation_depth']}")
        print(f"  State    : {r['state']}")
    faults_with_evidence = sum(
        1 for r in results if r["fault_mode"] != "NONE" and
        (r["steps_lost"] or r["infection_point"])
    )
    print(f"\n  Faults with evidence: {faults_with_evidence} / {len(results)-1}")
    print("=" * 72 + "\n")


def main():
    modes = sys.argv[1:] if len(sys.argv) > 1 else ALL_MODES
    if "NONE" not in modes:
        modes = ["NONE"] + modes

    print(f"\nRunning {len(modes)} fault modes...")
    results = []
    for mode in modes:
        print(f"  → {mode} ...", end=" ", flush=True)
        try:
            r = run_one(mode)
            results.append(r)
            print(f"done | steps={len(r['steps_reached'])}/{len(EXPECTED_STEPS)} | infects={r['infection_point']}")
        except Exception as e:
            print(f"ERROR: {e}")
            import traceback; traceback.print_exc()
            results.append({"fault_mode": mode, "error": str(e)})

    os.environ["FAULT_MODE"] = "NONE"
    print_report(results)

    out = "/results/emailserviceagent_fault_results.json"
    with open(out, "w") as f:
        json.dump({"generated_at": datetime.now(timezone.utc).isoformat(), "results": results}, f, indent=2)
    print(f"  Results saved to: {out}\n")

if __name__ == "__main__":
    main()
